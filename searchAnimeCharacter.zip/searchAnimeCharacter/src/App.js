import SearchAnimeCharacter from './SearchAnimeCharacter';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <>
    <SearchAnimeCharacter />
    </>
   
  );
}

export default App;
